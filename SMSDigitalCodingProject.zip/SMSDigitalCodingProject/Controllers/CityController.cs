﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SMSDigitalCodingProject.Interfaces;
using SMSDigitalCodingProject.Model;

namespace SMSDigitalCodingProject.Controllers
{
    [Authorize]
    [Route("api/city")]
    [ApiController]
    public class CityController : ControllerBase
    {
        private readonly ICityDetailRepo _ICity;

        public CityController(ICityDetailRepo ICity)
        {
            _ICity = ICity;
        }

        // GET: api/city>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CityDetail>>> Get()
        {
            return await Task.FromResult(_ICity.GetCityDetails());
        }

        // GET api/city/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CityDetail>> Get(int id)
        {
            var cities = await Task.FromResult(_ICity.GetCityDetails(id));
            if (cities == null)
            {
                return NotFound();
            }
            return cities;
        }

        // POST api/city
        [HttpPost]
        public async Task<ActionResult<CityDetail>> Post(CityDetail city)
        {
            _ICity.AddCityDetail(city);
            return await Task.FromResult(city);
        }

        // PUT api/city/5
        [HttpPut("{id}")]
        public async Task<ActionResult<CityDetail>> Put(int id, CityDetail city)
        {
            if (id != city.Id)
            {
                return BadRequest();
            }
            try
            {
                _ICity.UpdateCityDetail(city);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CityExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return await Task.FromResult(city);
        }

        // DELETE api/city/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<CityDetail>> Delete(int id)
        {
            var city = _ICity.DeleteCityDetail(id);
            return await Task.FromResult(city);
        }

        private bool CityExists(int id)
        {
            return _ICity.CheckCity(id);
        }

    }
}
