﻿using SMSDigitalCodingProject.Model;

namespace SMSDigitalCodingProject.Interfaces
{
    public interface ICityDetailRepo
    {
        public List<CityDetail> GetCityDetails();
        public CityDetail GetCityDetails(int id);
        public void AddCityDetail(CityDetail citydetail);
        public void UpdateCityDetail(CityDetail citydetail);
        public CityDetail DeleteCityDetail(int id);
        bool CheckCity(int id);
    }
}
