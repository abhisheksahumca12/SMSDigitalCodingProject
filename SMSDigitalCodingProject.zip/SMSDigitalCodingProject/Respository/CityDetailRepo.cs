﻿using Microsoft.EntityFrameworkCore;
using SMSDigitalCodingProject.Interfaces;
using SMSDigitalCodingProject.Model;

namespace SMSDigitalCodingProject.Respository
{
    public class CityDetailRepo : ICityDetailRepo
    {

        readonly DatabaseContext _dbContext;

        public CityDetailRepo(DatabaseContext dbContext)
        {
            _dbContext = dbContext;
        }

        public List<CityDetail> GetCityDetails()
        {
            try
            {
                return _dbContext.CityDetails.ToList();
            }
            catch
            {
                throw;
            }
        }

        public Model.CityDetail GetCityDetails(int id)
        {
            try
            {
                CityDetail? cityDetails = _dbContext.CityDetails.Find(id);
                if (cityDetails != null)
                {
                    return cityDetails;
                }
                else
                {
                    throw new ArgumentNullException();
                }
            }
            catch
            {
                throw;
            }
        }

        public void AddCityDetail(CityDetail citydetail)
        {
            try
            {
                _dbContext.CityDetails.Add(citydetail);
                _dbContext.SaveChanges();
            }
            catch
            {
                throw;
            }
        }

        public void UpdateCityDetail(CityDetail citydetail)
        {
            try
            {
                _dbContext.Entry(citydetail).State = EntityState.Modified;
                _dbContext.SaveChanges();
            }
            catch
            {
                throw;
            }
        }

        public Model.CityDetail DeleteCityDetail(int id)
        {
            try
            {
                CityDetail? cityDetail = _dbContext.CityDetails.Find(id);

                if (cityDetail != null)
                {
                    _dbContext.CityDetails.Remove(cityDetail);
                    _dbContext.SaveChanges();
                    return cityDetail;
                }
                else
                {
                    throw new ArgumentNullException();
                }
            }
            catch
            {
                throw;
            }
        }

        public bool CheckCity(int id)
        {
            return _dbContext.CityDetails.Any(e => e.Id == id);
        }
    }
}
